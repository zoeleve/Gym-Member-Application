package com.example.workout;

import org.junit.Test;

import static org.junit.Assert.*;

public class GymMemberTest {

    @Test
    public void getVisitLogs() {
    }
}